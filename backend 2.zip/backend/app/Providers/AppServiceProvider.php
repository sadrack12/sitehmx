<?php

namespace App\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        $this->loadRoutes();
    }

    protected function loadRoutes(): void
    {
        Route::prefix('api')->group(function () {
            if (file_exists(base_path('routes/api.php'))) {
                require base_path('routes/api.php');
            }
        });
        
        if (file_exists(base_path('routes/web.php'))) {
            require base_path('routes/web.php');
        }
    }
}

