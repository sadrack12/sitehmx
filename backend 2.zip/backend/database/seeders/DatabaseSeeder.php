<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Administrador',
            'email' => 'admin@sitehmx.com',
            'password' => Hash::make('password'),
            'role' => 'admin',
        ]);

        User::create([
            'name' => 'Gestor',
            'email' => 'gestor@sitehmx.com',
            'password' => Hash::make('password'),
            'role' => 'gestor',
        ]);

        $this->call([
            MedicamentoSeeder::class,
            ExameSeeder::class,
            ServicoSeeder::class,
        ]);
    }
}

